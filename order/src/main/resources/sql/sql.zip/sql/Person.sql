/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-04-19 18:49:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for person
-- ----------------------------
DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `id` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `orgId` varchar(50) DEFAULT NULL COMMENT '机构Id',
  `updateTime` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `createTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `logicalDel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of person
-- ----------------------------
INSERT INTO `person` VALUES ('1', 'name', '1', '2017-04-19 14:20:31.251848', '1990-01-01 00:00:00.000000', '0');

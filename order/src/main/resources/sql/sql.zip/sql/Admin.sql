/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-04-19 18:49:31
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` varchar(50) NOT NULL,
  `account` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `update` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `createTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `logicalDel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('che001', 'che001', 'che001', '0', '2017-04-19 14:26:58.761595', '2017-04-19 14:26:55.000000', '0');

/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-04-19 18:49:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-早餐 1-午餐 2-饮料',
  `updateTime` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `createTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `logicalDel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', 'cc1', '1', '2017-04-19 14:11:39.495678', '2017-04-19 14:11:37.000000', '0');
INSERT INTO `order` VALUES ('2', 'cc2', '1', '2017-04-19 14:11:41.708899', '2017-04-19 14:11:40.000000', '0');
INSERT INTO `order` VALUES ('3', 'cc3', '1', '2017-04-19 14:11:44.041133', '2017-04-19 14:11:42.000000', '0');
INSERT INTO `order` VALUES ('4', 'cc4', '1', '2017-04-19 14:11:46.250353', '2017-04-19 14:11:44.000000', '0');
INSERT INTO `order` VALUES ('5', 'cc5', '1', '2017-04-19 14:11:48.559584', '2017-04-19 14:11:47.000000', '0');
INSERT INTO `order` VALUES ('6', 'cc6', '1', '2017-04-19 14:11:50.852814', '2017-04-19 14:11:49.000000', '0');
INSERT INTO `order` VALUES ('7', 'cc7', '1', '2017-04-19 14:11:52.974026', '2017-04-19 14:11:51.000000', '0');
INSERT INTO `order` VALUES ('8', 'dd1', '3', '2017-04-19 14:11:55.248253', '2017-04-19 14:11:53.000000', '0');
INSERT INTO `order` VALUES ('9', 'dd2', '3', '2017-04-19 14:11:57.700498', '2017-04-19 14:11:55.000000', '0');

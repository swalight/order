/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-04-19 18:49:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for top
-- ----------------------------
DROP TABLE IF EXISTS `top`;
CREATE TABLE `top` (
  `id` varchar(50) NOT NULL,
  `top1` varchar(60) DEFAULT NULL,
  `top2` varchar(60) DEFAULT NULL,
  `top3` varchar(60) DEFAULT NULL,
  `top4` varchar(60) DEFAULT NULL,
  `top5` varchar(60) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `countTime` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updateTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `createTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `logicalDel` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of top
-- ----------------------------
INSERT INTO `top` VALUES ('breakfast', null, null, null, null, null, '1', '2017-04-19 14:26:20.134733', '2017-04-19 14:26:18.000000', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `top` VALUES ('drink', null, null, null, null, null, '1', '2017-04-19 14:26:22.769997', '2017-04-19 14:26:21.000000', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `top` VALUES ('lunch', null, null, null, null, null, '1', '2017-04-19 14:26:26.362356', '2017-04-19 14:26:24.000000', '1990-01-01 00:00:00.000000', '0');

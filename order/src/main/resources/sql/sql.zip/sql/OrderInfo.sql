/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2017-04-19 18:49:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for orderinfo
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo` (
  `id` varchar(50) NOT NULL,
  `personId` varchar(20) NOT NULL,
  `orderId` varchar(50) DEFAULT NULL,
  `week` tinyint(1) DEFAULT NULL COMMENT '1 2 3 4 5 6 7 七天',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-早餐 1-午餐 2-饮料',
  `updateTime` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `createTime` timestamp(6) NOT NULL DEFAULT '1990-01-01 00:00:00.000000',
  `logicalDel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------
INSERT INTO `orderinfo` VALUES ('1', '1', '1', '1', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('11', '1', '8', '1', '3', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('2', '1', '2', '2', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('22', '1', '8', '2', '3', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('3', '1', '3', '3', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('33', '1', '8', '3', '3', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('4', '1', '4', '4', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('44', '1', '9', '4', '3', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('5', '1', '5', '5', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('6', '1', '6', '6', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
INSERT INTO `orderinfo` VALUES ('7', '1', '7', '7', '1', '2017-04-19 14:16:52.061932', '1990-01-01 00:00:00.000000', '0');
